const mongoose=require("mongoose");
const feedSchema=mongoose.Schema({
    feed:String
})

const feedModel=mongoose.model("messages",feedSchema)

module.exports=feedModel;