const mongoose=require("mongoose");
const contactSchema=mongoose.Schema({
    email:String,
    name:String,
    subject:String,
    message:String
})

const contactModel=mongoose.model("contacts",contactSchema)

module.exports=contactModel;