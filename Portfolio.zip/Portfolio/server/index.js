const express=require("express");
const mongoose=require("mongoose");
const cors=require("cors");
const app=express();
const contactModel=require('./models/model')
const feedModel=require('./models/feed')
app.use(express.json());
app.use(cors());

mongoose.connect("mongodb://localhost:27017/Portfolio");

app.post('/contact',(req,res)=>{
contactModel.create(req.body)
.then(contacts=> res.json(contacts))
.catch(err=>res.json(err))
})

app.post('/feedback',(req,res)=>{
    feedModel.create(req.body)
    .then(feed=> res.json(feed))
    .catch(err=>res.json(err))
    })

app.listen(3001,()=>{
    console.log("Server is running at 3001");
})