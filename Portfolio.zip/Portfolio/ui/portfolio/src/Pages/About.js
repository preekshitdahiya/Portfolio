import React from 'react';
 
function About(){
    return (
        <>
        <div id="bg" >
            <div className="container-fluid" id="head">
  <h1  className="fs-1  text-info  text-center" >About Me</h1>
  </div>

<div className="row container-fluid">
<div id="box1" className="col-12 col-lg-4 col-md-4">
     <img  id="image" className=" d-flex justify-content-center  mx-auto mt-3" src="./images/Preekshit.png" alt='My_Photo' />
</div>
       <div id="box2" className="col-12 col-lg-8  col-md-8 ">
          <p  className="fs-5 ">A methodical, creative, innovative, focused, hard working and enthusiastic under-graduate possessing excellent problem-solving, analytical, communication and leadership skills with an aptitude to explore suitable avenues of computer Science Engineering while developing advanced projects with efficency and quality.
                      </p>
                      <br></br>
    <table class="table table-borderless ">
                      
  
  <tbody>
    <tr>
      <th scope="row">Name </th>
      <td>:</td>
      <td>Preekshit Dahiya</td>
      
    </tr>
    <tr>
      <th scope="row">Date of Birth</th>
      <td>:</td>
      <td>01/10/2001</td>
    </tr>
    <tr>
    <th scope="row">Address </th>
      <td>:</td>
      <td>Saharanpur, Uttar Pradesh </td>
    </tr>
    <tr>
    <th scope="row">PinCode </th>
      <td>:</td>
      <td>247231 </td>
    </tr>
    <tr>
    <th scope="row">Phone </th>
      <td>:</td>
      <td>+91-8218882128 </td>
    </tr>
  </tbody>
</table>
 

         
     <a  type="button" className="btn btn-primary d-block mx-auto ms-1" href="RESUME.pdf" download="CV.pdf">Download CV</a>
     <br></br>
       </div>
</div>
          <div  className='container'>
            <div  className='row'>
          <div className='col-12 col-lg-2 col-md-6'> <img id="i1" src="./images/HTML.png" className="rounded " alt="HTML5"/></div>
          <div className='col-12 col-lg-2 col-md-6'><img id="i1" src="./images/CSS.png" className="rounded " alt="CSS3"/></div>
          <div className='col-12 col-lg-2 col-md-6'> <img id="i1" src="./images/Bootstrap.png" className="rounded " alt="Bootstrap"/></div>
          <div className='col-12 col-lg-2 col-md-6'> <img id="i1" src="./images/Javascript.png" className="rounded " alt="Javascript"/></div>
          <div className='col-12 col-lg-2 col-md-6'><img id="i1" src="./logo512.png" className="rounded " alt="ReactJs"/></div>
          <div className='col-12 col-lg-2 col-md-6'><img id="i1" src="./images/PHP.png" className="rounded " alt="PHP"/></div>      
          
            </div> 
            <div  className='row'>
          <div className='col-12 col-lg-2 col-md-6'> <img id="i1" src="https://th.bing.com/th?id=OIP.bkbn2-K7c9rMBV5dvYXDrQHaIh&w=233&h=268&c=8&rs=1&qlt=90&o=6&dpr=1.3&pid=3.1&rm=2" className="rounded " alt="C"/></div>
          <div className='col-12 col-lg-2 col-md-6'><img id="i1" src="./images/c++.png" className="rounded " alt="C++"/></div>
          <div className='col-12 col-lg-2 col-md-6'> <img id="i1" src="./images/Java.png" className="rounded " alt="Java"/></div>
          <div className='col-12 col-lg-2 col-md-6'> <img id="i1" src="https://th.bing.com/th/id/OIP.TL-NrthBxVBXtJ7rerXGEQHaHa?rs=1&pid=ImgDetMain" className="rounded " alt="My SQL"/></div>
          <div className='col-12 col-lg-2 col-md-6'><img id="i1" src="https://images-na.ssl-images-amazon.com/images/I/41QodfboFdL.png" className="rounded " alt="Oracle"/></div>
          <div className='col-12 col-lg-2 col-md-6'><img id="i1" src="https://th.bing.com/th/id/R.37f54d01a714f59e09ff47b51c1ea3e7?rik=4m18AhthqWTuFQ&riu=http%3a%2f%2fwww.deepnetsecurity.com%2fwp-content%2fuploads%2f2014%2f03%2fwindows-logo.jpg&ehk=fcV3g6MDWpvHvn25A%2b%2fD0NyLB9Hg8nVukGFx4PjVxPU%3d&risl=&pid=ImgRaw&r=0" className="rounded " alt="Windows"/></div>      
          
            </div> 
<br></br>
        </div>



          </div>
        </>
    )
}
export default About;