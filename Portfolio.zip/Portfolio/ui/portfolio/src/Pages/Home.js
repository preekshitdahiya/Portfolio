import React from 'react';

function Home(){
    return(
        
<div id="body">

<div id="home">
    <div id="inner" className="card mb-3" >
  <div className="row g-0">

    <div id="intro"className="col-md-8">
      <div className="card-body">
        <h3 className="card-text">Hi! I am</h3>
        <h1 className="card-title">Preekshit Dahiya</h1>
        <h3 className="card-text">I am a Fullstack Developer.</h3>
        
      </div>
    </div>

    <div id="pic" className="col-md-4">
      <img id="img" src="./images/Preekshit.jpg" className="img-fluid " alt="..."/>
    </div>
  </div>
</div>
</div>

</div>
    )
}
export default Home;