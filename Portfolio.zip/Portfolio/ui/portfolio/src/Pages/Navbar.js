import React from 'react';
import { Outlet,NavLink } from 'react-router-dom';
 function Navbar(){
return(
  <>
<nav id="navbar" className="navbar  Sticky-top">
  <div className="container-fluid">
    <NavLink id="heading" className="navbar-brand" to="/">Preekshit</NavLink>
    <button className="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
      <span className="navbar-toggler-icon"></span>
    </button>
    <div className="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
      <div className="offcanvas-header">
        <h5 className="offcanvas-title" id="offcanvasNavbarLabel">Menu</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" data-bs-target="#my-offcanvas" aria-label="Close"></button>
      </div>
      <div className="offcanvas-body">
        <ul className="navbar-nav justify-content-end flex-grow-1 pe-3">
          <li className="nav-item">
            <NavLink className="nav-link active" aria-current="page" to="/">Home</NavLink>
          </li>
          <li className="nav-item">
            <NavLink className="nav-link" to="/About_Me">About_Me</NavLink>
          </li>
          <li className="nav-item dropdown">
            <NavLink className="nav-link " to="/Education" >
            Education
            </NavLink>
           
          </li>
          <li className="nav-item">
            <NavLink className="nav-link" to="/Services">Services</NavLink>
          </li>
          <li className="nav-item">
            <NavLink className="nav-link" to="/Project">Project</NavLink>
          </li>
          <li className="nav-item">
            <NavLink className="nav-link" to="/Contact_Me">Contact_Me</NavLink>
          </li>
        </ul>
             </div>
    </div>
  </div>
 
</nav>
<Outlet/>
</>


)
}
export default Navbar;