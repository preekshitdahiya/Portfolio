import React from 'react';

function  Education()
    {
        return(
            < div className='box '>
              
            <div className="row">
            <div className="container-fluid" id="head">
           <h1  className="fs-1    text-center" >Education</h1>
           </div>

         

  <div className="col-4">
    <div id="list-example" className="list-group">
      <a id="A1" className="list-group-item list-group-item-action" href="#list-item-1">Schooling</a>
      <a id="A1" className="list-group-item list-group-item-action" href="#list-item-2">Experience</a>
      <a id="A1" className="list-group-item list-group-item-action" href="#list-item-3">Skills</a>
      <a id="A1" className="list-group-item list-group-item-action" href="#list-item-3">Academic Achivements</a>
      
    </div>
  </div>
  <div className="col-8">
    <div data-bs-spy="scroll" data-bs-target="#list-example" data-bs-smooth-scroll="true" className="scrollspy-example" tabindex="0">
    <div id="list-item-1"><img src="./images/education.png" alt="..."/><h1>Schooling</h1></div>
      <h4>2020-2024</h4>
            <h4>Graduation</h4>
      <p>Bachelors of Technology, Computer Science and Engineering<br></br>
      Chandigarh Group of Colleges, Landran, Mohali<br></br>
      CGPA: 8.9
      </p>
             
                <hr/>
              

              <h4>2019-2020</h4>
            <h4>Intermediate</h4>
      <    p>CBSE, Lord Mahavira Academy, Saharanpur<br></br>
            Percentage: 96.6%</p>
            
                <hr />
             

              <h4>2017-2018</h4>
            <h4>Matriculation</h4>
           < p>CBSE, Lord Mahavira Academy, Saharanpur<br></br>
            Percentage: 94.8%</p>
           
                <hr />
           

      <div id="list-item-2"><img src="./images/experience .png" alt="..."/><h1>Experience</h1></div>
      <p>
        <ul>
        <li> ISO 9001 Certfication in Fullstack from Future Finders.</li>
        <li> Training in React Js from Solitaire Infosys Pvt. Ltd.</li>
        <li> Career start program in Artificial Intelligence from Internship Studio. </li>
        <li> Training in React Js from Solitaire Infosys Pvt. Ltd.</li>
        </ul>
        
      </p>
                 <hr/>


       <div id="list-item-3"><img src="./images/skills.png" alt="..."/><h1>Skills</h1></div>
      <h4>Interpersonal Skills:</h4>
      <ul>
        <li> Team Spirit</li>
        <li> Creative and Innovative</li>
        <li> Decision making and Analytical skills </li>
        <li> Speaking and Writing skills</li>
        <li> Quick Learner</li>
        </ul>
<hr></hr>
      <h4>Technical Skills:</h4>
      <ul>
        <li> OS: Windows, Ubuntu</li>
        <li> Languages: C, C++(DSA), Java, HTML, CSS, Javascript, Bootstrap, React Js</li>
        <li> Databases: MySQL, MS Excel, Oracle </li>
        </ul>
<hr></hr>
<div id="list-item-4"><img src="./images/achivements.png" alt="..."/><h1>Academic Achivements</h1></div>
        <ul>
        <li> Published paper in IJEST journal on HCI</li>
        <li> Qualified GATE CS 2024 with the score of 422</li>
        <li> Winner of 'Code like Ninja' event in Envision 2k22 competition in CGC Landran</li>
        <li> Secured 5 star badge at Hackerrank in C++ </li>
        <li>Enrolled in district level(IISEF) Science Olympiad with 1st rank</li>
        </ul>

    </div>
  </div>
</div>

            </div>
        )
    }

export default Education;