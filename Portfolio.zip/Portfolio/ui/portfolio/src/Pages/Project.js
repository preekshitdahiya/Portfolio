import React from 'react';

function  Project()
    {
        return(
            <>
                   <div className="container-fluid" id="head">
  <h1 className="fs-1   text-center" >Projects</h1>
  </div>
   <div id="box">
  <p className='text-center'> Following are the few projects that are completed by me.
  </p>

  
  <div className="row">
    <div className="col-12 col-lg-3 col-md-6 d-flex justify-content-center mb-3">
  <div  className="card" >
    <img src="./images/the resto.png" className="card-img-top mx-auto rounded-circle mt-3" alt="..."  />
    <div className="card-body">
      <h5 className="card-title text-center text-info">The Resto</h5>
      <p className="card-text text-center">Technology: React Js, HTML, CSS, Bootstrap.<br></br>This is food delivery website for a restraunt named 'THE RESTO'. It has simple and responsive design.</p>
      
    </div>
  </div>
  </div>

  <div className="col-12 col-lg-3 col-md-6 d-flex justify-content-center mb-3">
    <div  className="card" >
      <img  src="./images/campus.png" className="card-img-top mx-auto rounded-circle mt-3" alt="..." />
      <div className="card-body">
        <h5 className="card-title text-center text-info">EasyPlacement.com</h5>
        <p className="card-text text-center">Technology: HTML, CSS, Javascript, PHP, Firebase.<br></br> It is a degetal platform forming a link between campus students and companies as well as with placement cell of the campus.</p>
        
      </div>
    </div>
    </div>
  

  <div className="col-12 col-lg-3 col-md-6 d-flex justify-content-center mb-3">
    <div  className="card" >
      <img src="./images/study.png" className="card-img-top mx-auto rounded-circle mt-3" alt="..."  />
      <div className="card-body">
        <h5 className="card-title text-center text-info">ExamPreparation.com</h5>
        <p className="card-text text-center">Technolgy:HTML, CSS, React Js.<br></br>It is a tutorial website with simple and one click navigation menu providing study material according to the various subjects.</p>
        
      </div>
    </div>
    </div>

    <div className="col-12 col-lg-3 col-md-6 d-flex justify-content-center mb-3 ">
      <div  className="card" >
        <img src="./images/hospital.png" className="card-img-top mx-auto rounded-circle mt-3" alt="..."  />
        <div className="card-body">
          <h5 className="card-title text-center text-info">OPD Registration</h5>
          <p className="card-text text-center">Technology: C++.<br></br>It is an alternative for manual registration system of Community Health Centers. It generates the digital OPD slip with patient details.</p>
          
        </div>
      </div>
      </div>
  </div>
 
  </div>
            </>
        )
    }

export default Project;