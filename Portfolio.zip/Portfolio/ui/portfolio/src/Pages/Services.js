import React from 'react';

function  Services()
    {
        return(
            <>

               <div className="container-fluid" id="head">
  <h1 className="fs-1   text-center" >Services</h1>
  </div>
   <div id="box">
  <p className=" text-center">Following are the services that I can yield to the employers.
  </p>

  
  <div className="row">
    <div className="col-12 col-md-6 col-lg-3  d-flex justify-content-center mb-3">
  <div  className="card" >
    <img src="./images/engineering.png" className="card-img-top mx-auto rounded-circle mt-3" alt="..."  />
    <div className="card-body">
      <h5 className="card-title text-center text-info">Engineering</h5>
      <p className="card-text text-center">As an Engineering graduate, I favour to design, build, modify and devlop new technologies and machines.</p>
      
    </div>
  </div>
  </div>

  <div className="col-12 col-md-6 col-lg-3  d-flex justify-content-center mb-3">
    <div  className="card" >
      <img  src="./images/web-designing.png" className="card-img-top mx-auto rounded-circle mt-3" alt="..." />
      <div className="card-body">
        <h5 className="card-title text-center text-info">Web Desinging</h5>
        <p className="card-text text-center">Being a creative person, I opt to design the websites with more attracting and responsive designs producing easy to use websites.</p>
        
      </div>
    </div>
    </div>
  

  <div className="col-12 col-md-6 col-lg-3  d-flex justify-content-center mb-3">
    <div  className="card" >
      <img src="./images/researching.png" className="card-img-top mx-auto rounded-circle mt-3" alt="..."  />
      <div className="card-body">
        <h5 className="card-title text-center text-info">Researching</h5>
        <p className="card-text text-center">Innovation is the core skill of an engineer. With the ample innovation, I tend to research and produce better outputs.</p>
        
      </div>
    </div>
    </div>

    <div className="col-12 col-md-6 col-lg-3  d-flex justify-content-center mb-3 ">
      <div  className="card" >
        <img src="./images/strategy.png" className="card-img-top mx-auto rounded-circle mt-3" alt="..."  />
        <div className="card-body">
          <h5 className="card-title text-center text-info">Product Strategy</h5>
          <p className="card-text text-center">It involves analyzing and prosper the strategies for betterment of products and their business.</p>
          
        </div>
      </div>
      </div>


      
  </div>
  <div className="row">
    <div className="col-12 col-md-6 col-lg-3  d-flex justify-content-center mb-3">
  <div  className="card" >
    <img src="./images/software.png" className="card-img-top mx-auto rounded-circle mt-3" alt="..."  />
    <div className="card-body">
      <h5 className="card-title text-center text-info">Software Development</h5>
      <p className="card-text text-center">It involves the activity of creating computer programs; which involves designing, developing, testing, deploying, and maintaing the softwares.</p>
      
    </div>
  </div>
  </div>

  <div className="col-12 col-md-6 col-lg-3  d-flex justify-content-center mb-3">
    <div  className="card" >
      <img  src="./images/fullstack.png" className="card-img-top mx-auto rounded-circle mt-3" alt="..." />
      <div className="card-body">
        <h5 className="card-title text-center text-info">Fullstack Development</h5>
        <p className="card-text text-center">It imply to the development of both front end(client side) and back end(server side) portions of web application.</p>
        
      </div>
    </div>
    </div>
  

  <div className="col-12 col-md-6 col-lg-3  d-flex justify-content-center mb-3">
    <div  className="card" >
      <img src="./images/writing.png" className="card-img-top mx-auto rounded-circle mt-3" alt="..."  />
      <div className="card-body">
        <h5 className="card-title text-center text-info">Content Writing</h5>
        <p className="card-text text-center">It embrace the process of planning, writing, and publishing web content to satisfy the needs of a specific audience.</p>
        
      </div>
    </div>
    </div>

    <div className="col-12  col-md-6 col-lg-3  d-flex justify-content-center mb-3 ">
      <div  className="card" >
        <img src="./images/product.png" className="card-img-top mx-auto rounded-circle mt-3" alt="..."  />
        <div className="card-body">
          <h5 className="card-title text-center text-info">Product Development</h5>
          <p className="card-text text-center">It comprise of the process that covers the practical aspects of designs and prototypes, such as cost, functionality, and structure of the product.</p>
          
        </div>
      </div>
      </div>
   </div>
</div>
            </>
        )
    }
export default Services;