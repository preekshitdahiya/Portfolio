import React from 'react';
import Home from './Pages/Home.js';
import Navbar from './Pages/Navbar.js';
import About from './Pages/About.js';
import Footer from './Pages/Footer.js';
import Education from './Pages/Education.js';
import Services from './Pages/Services.js';
import Project from './Pages/Project.js';
import Contact from './Pages/Contact.js';

import {BrowserRouter as Router,Routes,Route} from 'react-router-dom';

function App() {
  return (
    <div> 
  
        <Router>
        <Navbar/>
         <Routes>
            <Route path="/" element={<Home/>}/>
                      
            <Route path="/About_Me" element={<About/>}/> 
            
            <Route path="/Education" element={<Education/>}/>
            
            <Route path="/Services" element={<Services/>}/>
             
            <Route path="/Project" element={<Project/>}/>

             <Route path="/Contact_Me" element={<Contact/>}/>  
           </Routes>
           <Footer/>
        </Router>
  
   
   
  
   </div>
  );
}

export default App;
